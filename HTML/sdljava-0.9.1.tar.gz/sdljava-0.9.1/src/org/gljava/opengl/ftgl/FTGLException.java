package org.gljava.opengl.ftgl;

public class FTGLException extends Exception {

    public FTGLException(String msg) {
	super(msg);
    }

    public FTGLException() {
	super();
    }
}