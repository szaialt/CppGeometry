package org.gljava.opengl;

public class GLException extends RuntimeException {

    public GLException() {
	super();
    }

    public GLException(String msg) {
	super(msg);
    }
}

  