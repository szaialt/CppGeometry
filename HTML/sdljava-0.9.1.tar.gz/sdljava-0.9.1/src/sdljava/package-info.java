/**

Provides the interface to SDL routines defined in SDL.h

<h2>Package Specification</h2>

Detailed documentation can be found here:

<ul>
  <li><a href="http://www.libsdl.org/cgi/docwiki.cgi/SDL_20API">SDL API</a>
</ul>

*/
package sdljava;