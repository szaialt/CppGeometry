package sdljava.event;

public class DummyEvent extends SDLEvent {

    /**
     * The type of the this event
     *
     * @return The type of event
     */
    public int getType() {
	return -1;
    }
}