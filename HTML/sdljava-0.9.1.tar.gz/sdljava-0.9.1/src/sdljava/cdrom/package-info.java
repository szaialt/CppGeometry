/**

Provides all the routines defined in the SDL_cdrom.h header.

<h2>Package Specification</h2>

<P>
Detailed documentation can be found here:

<ul>
  <li><a href="http://www.libsdl.org/cgi/docwiki.cgi/SDL_20API">SDL API</a>
</ul>

*/
package sdljava.cdrom;