/**

Provides the native interface (proxy) layer to the SDL C API.  All files in this package
are generated via <a href="http://www.swig.org">SWIG</a>.

*/
package sdljava.x.swig;