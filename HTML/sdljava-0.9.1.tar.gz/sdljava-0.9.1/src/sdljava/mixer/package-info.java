/**

Provides all the functions which are defined in the SDL_mixer.h header

<h2>Package Specification</h2>

<ul>
  <LI><a href="http://www.libsdl.org/projects/SDL_mixer/">SDL_mixer API</a> or greater </LI>
  <li><a href="http://www.libsdl.org/cgi/docwiki.cgi/SDL_20API">SDL API</a>
</ul>

<!--
<h2>Related Documentation</h2>
For overviews, tutorials, examples, guides, and tool documentation, please see:
<ul>
  <li><a href="">##### REFER TO NON-SPEC DOCUMENTATION HERE #####</a>
</ul>
-->

<!-- Put @see and @since tags down here. -->

*/
package sdljava.mixer;