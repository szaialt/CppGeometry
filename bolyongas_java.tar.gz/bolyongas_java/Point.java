public class Point {
  private int x;
  private int y;

  public int getX(){
    int a = x;
    return a;
  }

  public int getY(){
    int b = y;
    return b;
  }

  public void setX(int x){
    this.x = x;
  }

  public void setY(int y){
    this.y = y;
  }
}